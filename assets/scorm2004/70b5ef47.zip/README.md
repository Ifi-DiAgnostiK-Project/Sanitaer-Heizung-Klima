<!--
author:    Hilke Domsch
email:     hilke.domsch@gkz-ev.de
date:      2025-07-23
version:   0.1.2

language:  de
narrator:  Deutsch Male

comment:   Löten und Schweißen

edit:      https://liascript.github.io/LiveEditor/?/github/Ifi-DiAgnostiK-Project/shk-arbeitsschutz-loeten-schweissen

logo:      assets/images/burning.jpg
icon:      https://ifi-diagnostik-project.github.io/assets/img/Logo_234px.png

link:      style.css
import:    https://raw.githubusercontent.com/Ifi-DiAgnostiK-Project/Piktogramme/refs/heads/main/makros.md
           https://raw.githubusercontent.com/Ifi-DiAgnostiK-Project/LiaScript_DragAndDrop_Template/refs/heads/main/README.md
           https://raw.githubusercontent.com/Ifi-DiAgnostiK-Project/LiaScript_ImageQuiz/refs/heads/main/README.md

title:     Arbeits- und Gesundheitsschutz SHK-Anlagenmechaniker

tags:      SHK,
           Arbeitsschutz,
           Gesundheitsschutz,
           Anlagenmechaniker
-->

# Arbeits- und Gesundheitsschutz beim Löten und Schweißen 🦺

<section class="flex-container">

<div class="flex-child" style="min-width: 250px">

Im SHK-Handwerk arbeiten Sie mit Werkzeugen, Maschinen, Strom, Wasser und Gas – da ist Sicherheit besonders wichtig.

Arbeits- und Gesundheitsschutz bedeutet:

<!-- class="thumbup"-->
- Unfälle vermeiden
- gesund bleiben
- aufeinander achten

Dazu gehören, z.B.:

<!--class="checkmark"-->
- das Tragen von Schutzkleidung
- sicheres Heben
- sauberes Arbeiten
- das Beachten von Regeln auf der Baustelle

</div>

<div class="flex-child" style="min-width: 150px">
![SHK_Experte](assets/images/schutzkleidung.jpg "generiert durch DALL-E, eine OpenAI KI")<!-- style="width: 500px" -->

</div>
</section>

<!--class="highlight"-->
__Sicheres Arbeiten ist Teamarbeit – und Sie sind ein wichtiger Teil davon.__




## 1. Welche persönliche Schutzausrüstung (PSA) ist bei allen üblichen Schweißverfahren unbedingt erforderlich?

<!-- class="highlight" -->
__Ziehe alle richtigen Symbole in das Antwortfeld. 🤔__

@dragdropmultiple(@uid,@Gebotszeichen.Gesichtsschutz.src|@Gebotszeichen.Augenschutz.src|@Gebotszeichen.Handschuh.src,@Gebotszeichen.Rettungsweste_benutzen.src|@Gebotszeichen.Rueckhaltesystem.src)

_Piktogramme Quelle: BGHM_

## 2. Wichtige Schutzmaßnahmen beim Schweißen und Löten

> __Hinweis:__ Es können mehrere Antworten richtig sein.

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
__Entscheiden Sie, welche Maßnahmen der Arbeitssicherheit und des Gesundheitsschutzes für Löt- und Schweißarbeiten zu beachten sind.  🤔__

<!-- data-randomize -->
- [[X]] Schutzausrüstung
- [[X]] Belüftung
- [[ ]] Abstimmung mit den Kollegen
- [[X]] Löschmittel in unmittelbarer Nähe
- [[X]] gereinigte Arbeitsstücke
- [[ ]] Beaufsichtigung der Arbeiten durch einen erfahrenen Fachmann

</div>
</section>

<!-- class="highlight" -->
__Welche Schutzausrüstung und Sicherheitsmaßnahmen sind beim Löten und nach Arbeitsende zu beachten? Ziehen Sie die richtigen Bilder ins Antwortfeld. 🤔__

<!-- data-randomize data-show-partial-solution -->
@dragdropmultiple(@uid,@Gebotszeichen.Augenschutz.src|@Gebotszeichen.Handschuh.src|@Gebotszeichen.Schutzkleidung.src|@Brandschutzzeichen.Feuerloescher.src|@Gebotszeichen.Haende_waschen.src,@Gebotszeichen.Rettungsweste_benutzen.src|@Warnzeichen.Brandfoerdernde_Stoffe.src|@Warnzeichen.Heisse_Oberflaeche.src|@Warnzeichen.Laserstrahl.src|@Gebotszeichen.Kopfschutz.src)

_Piktogramme Quelle: BGHM_

## 3. Gefahren beim Schweißen

> __Hinweis:__ Es können mehrere Antworten richtig sein.

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
__Sind besondere Schutzmaßnahmen gegen elektrischen Strom beim Schweißen notwendig? 🤔__

<!-- data-randomize -->
- [[X]] Ja. Zum Beispiel durch eine Isoliermatte unter den Füßen
- [[X]] Ja. Zum Beispiel durch elektrisch isolierende Schutzhandschuhe und Sicherheitsschuhe
- [[ ]] Es sind keine besonderen Maßnahmen notwendig.

</div>
</section>

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
__Welche Risiken bestehen beim Schweißen?  🤔__


<!-- data-randomize -->
- [[X]] Gase und Dämpfe
- [[ ]] magnetische Strahlung
- [[X]] Elektrischer Schlag
- [[ ]] Schädigung des Gehörs durch Lichtbögen
- [[X]] Brände und Explosionen

</div>
<div class="flex-child-2 center">

![Schweißer mit Schutzhelm arbeitet an einem Metallstück, während helle Funken beim Schweißen entstehen.](assets/images/stick_welding_pipe.jpg "Schweißarbeiten in einer industriellen Umgebung mit sichtbarem Funkenflug. Bild von [saldahnae via Pixabay](https://pixabay.com/photos/welder-industrial-welding-working-5408909/), Pixabay Content License, veröffentlicht am 22. Juli 2020.")<!-- style="max-width: 550px; width: 100%; margin-left: -60px; margin-top:50px;" -->

</div>
</section>

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
__Was ist beim Elektroschweißen zum Schutz vor elektrischem Strom zu beachten? 🤔__

<!-- data-randomize -->
- [[ ]] Ein Schweißeranzug bietet ausreichenden Schutz gegen elektrische Gefährdung.
- [[X]] Bei Schweißarbeiten auf metallenem Untergrund setze ich Isoliermatten ein.
- [[X]] Nasse und durchschwitzte Kleidung hat eine erhöhte elektrische Leitfähigkeit und sollte gewechselt werden.
- [[ ]] Beim Tragen von Sicherheitsschuhen mit isollierender Sohle kann es zu keiner elektrischen Körperdurchströmung kommen.

</div>
</section>

## 4. Weitere Quizfragen zum Thema Schweißen - Teil 1

> __Hinweis:__ Es können mehrere Antworten richtig sein.


<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
__Wie zünde ich die Flamme eines Gasschweißgeräts korrekt an?__


<!-- data-randomize -->
- [( )] Mit einem herkömmlichen Feuerzeug
- [(X)] Mit einem speziellen Gasanzünder mit Feuerstein
- [( )] Mit einem Streichholz

</div>
<div class="flex-child">


![Brennerflamme erhitzt ein Stück Metall, während Funken und glühendes Material sichtbar sind.](assets/images/welding_torch.jpg "Metallbearbeitung mit Brennerflamme und sichtbaren Funken. Bild von [Shutterbug75 via Pixabay](https://pixabay.com/photos/acetylene-aluminium-aluminum-blow-1239330/), Pixabay Content License, veröffentlicht am 5. März 2016.")<!-- style="max-width: 250px; width: 100%; margin-left: 0px; margin-top:50px;" -->

</div>
</section>


<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
__Was ist beim Elektro-Handschweißen zu beachten? 🤔__

<!-- data-randomize -->
- [[ ]] Das Massekabel kann ich beliebig verlängern.
- [[X]] Ich nehme die Elektrode aus dem Elektrodenhalter und lege beides isoliert ab.
- [[X]] Zu meiner eigenen Sicherheit habe ich vor Arbeitsbeginn das Schweißgerät und die Leitung auf äußere Beschädigungen zu prüfen.
- [[ ]] Mit einem beschädigten Elektrodenhalter darf ich weiterarbeiten, wenn ich isolierende Schutzhandschuhe trage.
- [[ ]] Die elektrische Prüfung der Schweißstromquelle ist meine Aufgabe als Schweißer/Schweißerin.
- [[X]] Auch bei kurzfristigen Schweißarbeiten habe ich ein Schutzschild, einen Schutzschirm oder eine Schweißerschutzhaube zu tragen.


</div>
<div class="flex-child">


![Schweißhelm, Arbeitshandschuhe, Drahtbürste und Werkzeug liegen auf einem metallenen Arbeitstisch in einer Werkstatt.](assets/images/welding_hat.jpg "Arbeitsmaterial für Schweißarbeiten auf einem Metalltisch. Bild von [Benfe via Pixabay](https://pixabay.com/photos/work-material-vacancy-work-welder-3954244/), Pixabay Content License, veröffentlicht am 25. Januar 2019.")<!-- style="max-width: 250px; width: 100%; margin-left: 0px; margin-top:100px;" -->


</div>
</section>


<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
__Was ist beim Arbeiten mit dem Schweißbrenner zu beachten? 🤔__

<!-- data-randomize -->
- [[ ]] Das Ausmachen des Brenners erfolgt in der Reihenfolge: 1. Schließen des Sauerstoffventils, 2. Schließen des Brenngasventils
- [[X]] Der Schweißbrenner wird in folgender Reihenfolge gezündet: 1. Öffnen des Sauerstoffventil, 2. Öffnen des Brenngasventils
- [[X]] Heiße Brenner, die direkt an der Brenngasflasche angehängt werden, können zu einer punktförmigen Erhitzung der Flaschenwand führen und die gefährliche Zersetzung des Gases einleiten.

</div>
<div class="flex-child">


![Gasflasche mit Druckminderer und Schweißausrüstung, darunter ein Schweißschutzschild.](assets/images/welding_bottles.jpg "Schweißausrüstung mit Gasflasche, Druckminderer und Schutzschild. Bild von [Bru-nO via Pixabay](https://pixabay.com/photos/gas-welding-welder-protective-gas-2147487/), Pixabay Content License, veröffentlicht am 16. März 2017.")<!-- style="max-width: 250px; width: 100%; margin-left: 20px; margin-top:30px;" -->

</div>
</section>

## 5. Weitere Quizfragen zum Schweißen - Teil 2

> __Hinweis:__ Es können mehrere Antworten richtig sein.

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
__Welche Maßnahmen sind bei Schweißarbeiten an Behältern, die entzündbare oder explosive Stoffe enthalten, zu beachten? 🤔__

<!-- data-randomize -->
- [[ ]] Reste der Stoffe sind ungefährlich, solange diese nicht mit dem Lichtbogen des Schweißapparates in Berührung kommen.
- [[X]] Schweißarbeiten an geschlossenen Behältern darf ich nur unter Aufsicht ausführen.
- [[X]] Die Behälter müssen gereinigt und mit Wasser oder Schutzgas geflutet werden.
- [[ ]] Eine einfache Reinigung der Behälter mit Wasser ist ausreichend.

</div>
<div class="flex-child">


![Schweißer mit Schutzhelm arbeitet an Metall, während Funken beim Schweißen entstehen.](assets/images/pipe_weld.jpg "Schweißarbeiten in der Industrie mit Schutzhelm und Funkenflug. Bild von [wyllyston via Pixabay](https://pixabay.com/photos/welder-welding-industry-worker-4086983/), Pixabay Content License, veröffentlicht am 28. März 2019.")<!-- style="max-width: 250px; width: 100%; margin-left: 0px; margin-top:50px;" -->


</div>
</section>

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
__Welche Gefahren ergeben sich beim Autogenschweißen? Wie verhalten Sie sich? 🤔__

<!-- data-randomize -->
- [[X]] Durch die Enden der langen Schweißdrähte können Augen- und Gesichtsverletzungen verursacht werden. Deshalb biege ich die Enden rund.
- [[X]] Von der Schweißflamme und dem Schweißbad geht infrarote UV-Strahlung aus. Deshalb ist das Tragen einer Schutzbrille mit Seitenschutz Pflicht.
- [[ ]] Die Stärke der schädlichen Strahlung ist höher als beim Schutzgasschweißen, ich sollte deshalb einen kompletten Ganzkörperschutz tragen.
- [[ ]] Wegspritzende Schweißperlen kühlen so schnell ab, dass diese keine Verbrennungen verursachen.

</div>
<div class="flex-child">


![Illustration eines Schweißers mit Schutzmaske.](assets/images/soldering_puppet.jpg "Illustration eines Schweißers bei Metallarbeiten. Bild von [Peggy_Marco via Pixabay](https://pixabay.com/de/illustrations/schwei%c3%9fer-metall-angestellte-1825675/), Pixabay Content License, veröffentlicht am 18. November 2016.")<!-- style="max-width: 250px; width: 100%; margin-left: 0px; margin-top:50px;" -->


</div>
</section>

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
__Wie verhalten Sie sich bei Entstehungsbränden in der Nähe von Gasflaschen? 🤔__

<!-- data-randomize -->
- [[X]] Wenn möglich, schließe ich geöffnete Flaschenventile, warne die Kollegen/Kolleginnen, räume die Umgebung und alarmiere die Feuerwehr.
- [[ ]] Hat eine Acetylenzersetzung bereits begonnen, versuche ich das Sauerstoffventil zu schließen.
- [[X]] Ich lösche die Flamme mit Pulver- oder CO2-Löscher, und kühle bei Bränden in der Nähe von Acetylenflaschen die Flasche bis zum Eintreffen der Feuerwehr mit kaltem Wasser.

</div>
<div class="flex-child">


![Freigestellter roter Feuerlöscher vor transparentem bzw. hellem Hintergrund.](assets/images/fire_extinguisher.png "Roter Feuerlöscher als freigestelltes Brandschutzsymbol. Bild von [maja7777 via Pixabay](https://pixabay.com/photos/fire-extinguisher-isolated-2976921/), Pixabay Content License, veröffentlicht am 26. November 2017.")<!-- style="max-width: 150px; width: 100%; margin-left: 20px; margin-top:50px;" -->


</div>

</section>

## 6. Weitere Quizfragen zum Schweißen - Teil 3

> __Hinweis:__ Es können mehrere Antworten richtig sein.

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
Welche Kennzeichnung steht für Schweißstromquellen, die beim Schweißen mit erhöhter elektrischer Gefährung eingesetzt werden müssen?  🤔

<!-- data-randomize -->
- [( )] CE
- [(X)] S


</div>
<div class="flex-child">


![CE+S](assets/images/CE_sign.jpg "_Quelle: Hilke Domsch, GKZ_")<!-- style="max-width: 250px; width: 100%; margin-left: 0px; margin-top:0px;" -->

</div>
</section>

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
__Was tun Sie gegen elektrische Gefährdung beim Schweißen? 🤔__

<!-- data-randomize -->
- [[X]] Durch eine ausreichende Isolierung meines Standplatzes kann ich mich gegen eine elektrische Durchströmung meines Körpers schützen.
- [[X]] Kabel mit schadhafter Isolation darf ich nicht verwenden. Sie können beim Schweißen zu schweren Unfällen führen.
- [[ ]] Wenn ich Persönliche Schutzausrüstung benutze, kann keine elektrische Gefährdung entstehen.
- [[ ]] Der Massekontakt hat keinen Einfluss auf die elektrische Gefährdung.

</div>
<div class="flex-child">


![KI-generierte Illustration einer brennenden Fackel mit heller Flamme vor dunklem Hintergrund.](assets/images/burning.jpg "Brennende Fackel mit heller Flamme. Bild von [popmelon via Pixabay](https://pixabay.com/de/illustrations/brennende-fackel-fackel-flamme-8765143/), Pixabay Content License, veröffentlicht am 19. Mai 2024.")<!-- style="max-width: 550px; width: 100%; margin-left: 20px; margin-top:50px;" -->


</div>
</section>

## 7. Weitere Quizfragen zum Löten

> __Hinweis:__ Es können mehrere Antworten richtig sein.

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
__Sie löten. Worauf achten Sie? 🤔__


<!-- data-randomize -->
- [[X]] Ich darf den Kopf nicht direkt über die Lötstelle beugen.
- [[ ]] Bei Weichlötarbeiten Holzhäcksel als Feuerlöschmittel bereithalten.
- [[X]] Löt- und Flussmitteldämpfe sind gesundheitsschädlich, deshalb ist die richtige Einstellung der Absauganlage wichtig.


</div>
<div class="flex-child">


![Nahaufnahme einer heißen Lötspitze mit Rauch und flüssigem Lötzinn beim Löten.](assets/images/soldering.jpg "Lötspitze mit Rauch und flüssigem Lötzinn bei einer technischen Arbeit. Bild von [This_is_Engineering via Pixabay](https://pixabay.com/photos/engineer-engineering-solder-4904910/), Pixabay Content License, veröffentlicht am 6. März 2020.")<!-- style="max-width: 200px; width: 100%; margin-left: 0px; margin-top:0px;" -->


</div>
</section>

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
Auf was achten Sie beim Weichlöten?  🤔


<!-- data-randomize -->
- [[ ]] Weichlote können nicht überhitzen.
- [[ ]] Das Lötgerät bedarf im Gegensatz zum Schweißgerät keiner besonderen Überprüfung.
- [[X]] Beim Weichlöten besteht erhöhte Brandgefahr.
- [[X]] Beim Flammlöten muss die Schutzbrille zusätzlich Schutz gegen UV-Infrarotstrahlung bieten.

</div>
<div class="flex-child">


![Lötstation mit Lötkolben und Lötzinn auf einer Elektronik-Arbeitsfläche.](assets/images/soldering_utensils.jpg "Lötstation mit Lötkolben und Lötzinn für Arbeiten an Elektronik und Leiterplatten. Bild von [Bru-nO via Pixabay](https://pixabay.com/photos/soldering-soldering-station-tin-1038518/), Pixabay Content License, veröffentlicht am 13. November 2015.")<!-- style="max-width: 350px; width: 100%; margin-left: 0px; margin-top:0px;" -->


</div>
</section>

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
__Welche Gesundheitsgefahren bestehen beim Weichlöten? 🤔__


<!-- data-randomize -->
- [( )] Es gibt keine besonderen Gesundheitsgefahren beim Weichlöten.
- [(X)] Die Lot- und Flussmitteldämpfe sind gesundheitsschädlich.

</div>
<div class="flex-child">


![Hände eines Mannes bearbeiten ein Schmuckstück mit Werkzeug und Flamme an einer Werkbank.](assets/images/fine_soldering.jpg "Handwerkliche Schmuckbearbeitung mit Werkzeug und Flamme. Bild von [photosforyou via Pixabay](https://pixabay.com/photos/work-hand-man-craft-jewellery-3748395/), Pixabay Content License, veröffentlicht am 16. Oktober 2018.")<!-- style="max-width: 300px; width: 100%; margin-left: 0px; margin-top:0px;" -->


</div>
</section>

# Geschafft 🎉

![Bunte Silhouetten mehrerer springender Menschen vor weißem Hintergrund als Symbol für Freude, Spaß und Lebensfreude.](assets/images/colorfull_jumping.jpg "Farbige Silhouetten springender Menschen als Ausdruck von Freude und Spaß. Bild von [geralt via Pixabay](https://pixabay.com/de/illustrations/freude-springen-luftsprung-spa%C3%9F-3940425/), Pixabay Content License, veröffentlicht am 19. Januar 2019.")
